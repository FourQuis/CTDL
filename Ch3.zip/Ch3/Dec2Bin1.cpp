// Doi sang he nhi phan
#include <stdio.h>
#define MAX 32

void Dec2Bin(int n, int S[],int &);
main()
{
	int n,k=0,i,S[MAX];
		
	printf("n= "); scanf("%u",&n);
	Dec2Bin(n,S,k);
	for (i=k-1;i>=0;i--) printf("%d",S[i]);
}  

void Dec2Bin(int n, int S[],int &k)
{
	k=0;
	while (n>0){
		S[k++]=n%2;
		n/=2;
	}
}
