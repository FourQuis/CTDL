// Don toa thao kieu hang doi
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 10
void randperm(int P[],int n);

main()
{
	int n,nP,fQ,rQ,nA,i,j,iP,xA,P[MAX],Q[MAX],A[MAX];
	
	srand(time(NULL));
	n=rand()%(MAX-3)+3;	//n=4;
	printf("n=%d\n",n);	
	randperm(P,n);
	for (i=0; i<n;i++) printf("%d ",P[i]);
	nP=n;
	fQ=0; rQ=-1;
	nA=0; xA=0;
	iP=0;
	while (nA<n){
		i=iP; while (i<nP && P[i]!=xA+1) i++;	
		if (i<nP){//toa tiep theo o ray ban dau
			for (j=iP;j<i;j++)	Q[++rQ]=P[j]; iP=j; // don toa qua ray phu
			xA=A[nA]=P[iP]; nA++; iP++;
			printf("\n|");for (i=0; i<nA;i++) printf("%d ",A[i]);
			printf("|");for (i=fQ; i<=rQ;i++) printf("%d ",Q[i]);
			printf("|");for (i=0; i<iP;i++) printf(".");
			for (i=iP; i<nP;i++) printf("%d ",P[i]); printf("|");
			getchar();
		}
		else   
		if (Q[fQ]==xA+1){ //lay toa o ray phu
			xA=A[nA]=Q[fQ]; nA++; fQ++;
			printf("\n|");for (i=0; i<nA;i++) printf("%d ",A[i]);
			printf("|");for (i=fQ; i<=rQ;i++) printf("%d ",Q[i]);
			printf("|");for (i=0; i<iP;i++) printf(".");
			for (i=iP; i<nP;i++) printf("%d ",P[i]);printf("|");
			getchar();
		}
		else{
			printf("Khong don toa duoc...");
			break;
		}
	}
}

void randperm(int P[],int n)
{
  int i, j, k, N, t[MAX];
  
  N=n; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    P[i]=t[k]+1; 
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
  }
}
