// Doi sang he nhi phan
#include <stdio.h>
#define MAX 32

void Dec2Bin(int n, int S[],int &);
main()
{
	int n,k=0,i,P[MAX];
		
	printf("n= "); scanf("%u",&n);
	Dec2Bin(n,P,k);
	for (i=0;i<k;i++) printf("%d",P[i]);
}  

void Dec2Bin(int n, int P[],int &k)
{
	int i, j;
	
	k=0;
	while (n>0){
		P[k++]=n%2;
		n/=2;
	}
	for (i=0; i<k/2; i++){
		j=k-1-i;
		P[i]^=P[j]; P[j]^=P[i]; P[i]^=P[j];
	}
}
