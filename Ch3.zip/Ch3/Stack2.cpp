/* Khai bao ngan xep la danh sach lien ket
Viet chuong trinh nhap so nguy�n n v� thuc hien:
a)	Tao ngan xep S gom n so nguy�n trong khoang 0..n-1.
b)	Lan luot lay ra khoi ngan xep va in ra man hinh.
*/

#include <stdio.h>
#include <stdlib.h>


typedef struct pt{
	   int data;
	   struct pt *next;
	} phantu;

typedef phantu* STACK;

STACK S; 

void SetEmpty(STACK &S);
int IsEmpty(STACK S);
void Push(int x, STACK &S);
int Pop(STACK &S);

main()
{
  int i, n;
  	
  SetEmpty(S);
  printf("n= "); scanf("%d", &n);
  printf("\nThu tu Push:"); 
  for (i=0; i<n; i++){
  	printf("\n%d", i);
  	Push(i, S);
  } 
  printf("\nThu tu Pop:");
  while (!IsEmpty(S)) printf("\n%d", Pop(S));
}
 
void SetEmpty(STACK &S)
{
 	S=NULL;
}

int IsEmpty(STACK S)
{
 	return S==NULL;
}

void Push(int x, STACK &S)
{
	STACK p;
	
    p=(STACK) malloc(sizeof(phantu));
    p->data=x;
    p->next=S;
    S=p;	
}

int Pop(STACK &S)
{
  	int x;
  	
  	x=S->data;
  	S=S->next;
	return x;
}
