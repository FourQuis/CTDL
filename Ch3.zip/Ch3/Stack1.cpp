/* Khai bao ngan xep la danh sach dac
Viet chuong trinh nhap c�c so nguy�n n v� thuc hien:
a)	Tao ngan xep S gom n so nguy�n trong khoang 0..n-1.
b)	Lan luot lay ra khoi ngan xep va in ra man hinh.
*/

#include <stdio.h>

#define MAX 100

typedef int STACK[MAX];
STACK S; int n;

void SetEmpty(STACK S, int &n);
void Push(int x, STACK S, int &n);
int Pop(STACK S, int &n);

main()
{
  int i, N;
  	
  SetEmpty(S, n);
  printf("n= "); scanf("%d", &N);
  printf("\nThu tu Push:"); 
  for (i=0; i<N; i++){
  	printf("\n%d", i);
  	Push(i, S, n);
  } 
  printf("\nThu tu Pop:");
  while (n) printf("\n%d", Pop(S, n));
}
 
void SetEmpty(STACK S, int &n)
{
 	n=0;
}

void Push(int x, STACK S, int &n)
{
	S[n++]=x; 	
}

int Pop(STACK S, int &n)
{
  	return S[--n];
}
