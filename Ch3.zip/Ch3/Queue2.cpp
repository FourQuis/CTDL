/* Khai bao hang doi la danh sach lien ket
Viet chuong trinh nhap c�c so nguy�n n v� thuc hien:
a)	Tao hang doi Q gom n so nguy�n 0..n-1.
b)	Lan luot lay ra khoi hang doi va in ra man hinh.
*/

#include <stdio.h>
#include <stdlib.h>


typedef struct pt{
	   int data;
	   struct pt *next;
	} phantu;

typedef phantu* QUEUE;

QUEUE fQ, rQ; 

void SetEmpty(QUEUE &fQ);
int IsEmpty(QUEUE fQ);
void EnQueue(int x, QUEUE &rQ);
int DeQueue(QUEUE &fQ);

main()
{
  int i, n;
  	
  SetEmpty(fQ);
  printf("n= "); scanf("%d", &n);
  printf("\nThu tu EnQueue:"); 
  for (i=0; i<n; i++){
  	printf("\n%d", i);
  	EnQueue(i, rQ);
  } 
  printf("\nThu tu DeQueue:");
  while (!IsEmpty(fQ)) printf("\n%d", DeQueue(fQ));
}
 
void SetEmpty(QUEUE &fQ)
{
 	fQ=rQ=NULL;
}

int IsEmpty(QUEUE fQ)
{
	return fQ==NULL;
}

void EnQueue(int x, QUEUE &rQ)
{
	QUEUE p;
	
    p=(QUEUE) malloc(sizeof(phantu));
    p->data=x;
    p->next=NULL;
    if (IsEmpty(fQ)) fQ=rQ=p;
    else{
    	rQ->next=p;
		rQ=p;	
	}	
}

int DeQueue(QUEUE &fQ)
{
	int x;
  	
  	x=fQ->data;
  	fQ=fQ->next;
	return x; 	
}
