// Doi sang he nhi phan
#include <stdio.h>
#define MAX 32

void Dec2Bin(int n, int S[],int &);
main()
{
	int n,k=0,i,S[MAX];
		
	printf("n= "); scanf("%u",&n);
	Dec2Bin(n,S,k);
	for (i=0;i<k;i++) printf("%d",S[i]);
}  

void Dec2Bin(int n, int S[],int &k)
{
	if (n>0){
		Dec2Bin(n/2,S,k);
		S[k]=n%2; k++;
	}
}
