/* Khai bao hang doi la danh sach dac
Viet chuong trinh nhap c�c so nguy�n n v� thuc hien:
a)	Tao hang doi Q gom n so nguy�n 0..n-1.
b)	Lan luot lay ra khoi hang doi va in ra man hinh.
*/

#include <stdio.h>

#define MAX 100

typedef int QUEUE[MAX];
QUEUE Q; 
int fQ, rQ;

void SetEmpty(QUEUE Q, int &fQ, int &rQ);
int IsEmpty(QUEUE Q, int fQ, int rQ);
void EnQueue(int x, QUEUE Q, int &rQ);
int DeQueue(QUEUE Q, int &fQ);

main()
{
  int i, n;
  	
  SetEmpty(Q, fQ, rQ);
  printf("n= "); scanf("%d", &n);
  printf("\nThu tu EnQueue:"); 
  for (i=0; i<n; i++){
  	printf("\n%d", i);
  	EnQueue(i, Q, rQ);
  } 
  printf("\nThu tu DeQueue:");
  while (!IsEmpty(Q, fQ, rQ)) printf("\n%d", DeQueue(Q, fQ));
}
 
void SetEmpty(QUEUE Q, int &fQ, int &rQ)
{
 	fQ=0;
 	rQ=-1;
}

int IsEmpty(QUEUE Q, int fQ, int rQ)
{
	return fQ>rQ;
}

void EnQueue(int x, QUEUE Q, int &rQ)
{
	Q[++rQ]=x; 	
}

int DeQueue(QUEUE Q, int &fQ)
{
  	return Q[fQ++];
}
