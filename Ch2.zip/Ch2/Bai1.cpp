/*
Viet chuong trinh nhap c�c so nguy�n n, a, b (a>0, a<b<1000, n<b-a) v� thuc hien:
a)	Tao danh s�ch dac L1 gom n so nguy�n ngau nhi�n trong khoang [a; b].
b)	Tao danh s�ch dac L2 gom n so nguy�n ngau nhi�n kh�c nhau trong khoang [a; b].
c)	Noi L2 v�o L1 de tao danh s�ch L.
d)	Kiem tra t�nh don dieu cua danh s�ch L.
e)	Kiem tra t�nh doi xung cua danh s�ch L.
f)	Nhap so nguy�n x, sau do t�m phan tu dau ti�n trong danh s�ch L c� gi� tri bang x. 
	Neu t�m thay, ch�n phan tu (x-1) v�o truoc phan tu x v� phan tu (x+1) v�o sau phan tu x. 
	Neu kh�ng t�m thay, ch�n phan tu (x-1) v�o dau danh s�ch v� phan tu (x+1) v�o cuoi danh s�ch.
g)	Nhap mot so nguy�n x, 
	sau do x�c dinh xem c� bao nhi�u phan tu trong danh s�ch L c� gi� tri bang x. 
h)	Loai tat c� c�c phan tu c� gi� tri bang x ra khoi danh s�ch L.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100

//typedef int DS[MAX]

int a, b, c, x, L1[MAX], L2[MAX], L[MAX], n;

void InDS(int L[], int n);
void Nhapnab();
void caua(), caub(),cauc(),cauf(),cauh(),caug();
int caud(),caue();

main()
{
  system("COLOR F1");
  Nhapnab();
  c=b-a;
  //srand(time(NULL));
  caua(); printf("\n Danh sach L1:\n"); InDS(L1,n);
  caub(); printf("\n\n Danh sach khac nhau L2:\n"); InDS(L2,n);
  cauc(); printf("\n Danh sach L:\n"); InDS(L,n);
  printf("\n Danh sach %s don dieu...\n ", caud()?"":"khong");
  printf("\n Danh sach %s doi xung...\n ", caue()?"":"khong");
  cauf(); printf("\n Danh sach sau khi chen ...\n "); InDS(L,n);
  caug();
  cauh(); InDS(L,n);
}
 
void InDS(int L[], int n)
{
 	for (int i=0; i<n; i++) printf("\n%3d: %d ",i+1, L[i]);
}

void Nhapnab()
{
 	printf("a= "); scanf("%d", &a);
 	printf("b>a : "); scanf("%d", &b);
 	printf("n<b-a : "); scanf("%d", &n);
 	printf("\n Danh sach gom cac so nhap trong [%d;%d]\n",a,b);
}

void caua()
{
  	int i;
  	
  	for (i=0; i<n; i++) L1[i]=rand()%c+a;
}

void caub()
{
  int i, j, k, N, t[1000];
  
  N=c; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    //printf("\n Loai phan tu thu %d = %d", k, t[k]);
    L2[i]=t[k]+a; 
	//printf("\n Loai %d dua %d vao L2", t[k], L2[i]);
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
  }
}

void cauc()
{
  int i;

  for (i=0; i<n; i++) L[i]=L1[i];
  for (i=0; i<n; i++) L[n+i]=L2[i];
  n*=2;
}

int caud()
{
  int i, sign;

  sign=L[1]-L[0]; // khong can kiem tra sign=0
  for (i=1; i<n-1; i++)
    if (sign*(L[i+1]-L[i])<=0) return 0;
  return 1;
}

int caue()
{
  int i, j;

  i=0; j=n-1;
  while (i<j && L[i]==L[j]){
    i++; j--;
  }
  return i>=j;
}

void cauf()
{
  int i, j;

  printf("\n Chen x-1 va x+1 vao L, x= "); scanf("%d", &x);
  i=0;
  while (i<n && L[i]!=x) i++;
  if (i<n){ // co L[i]=x
    for (j=n; j>i; j--) L[j]=L[j-1];
    L[i]=x-1; i++; n++;
    for (j=n; j>i+1; j--) L[j]=L[j-1];
    L[i+1]=x+1; n++;
  }
  else{ // khong co L[i]=x
  	  for (j=n; j>0; j--) L[j]=L[j-1]; L[0]=x-1; n++;
  	  L[n]=x+1; n++;
  }
}

void caug()
{
  int i,x,c;

  printf("\n So can dem x= "); scanf("%d", &x);
  c=0;
  for (i=0; i<n; i++) if (L[i]==x) c++;
  printf("\n Danh sach co %d so %d ...\n ", c, x); 
}

void cauh()
{
  int i, j;
  printf("\n Cac so can loai x= "); scanf("%d", &x);
  i=0;
  while (i<n){
    if (L[i]!=x) i++;
    else{
	      for (j=i; j<n; j++) L[j]=L[j+1];
	      n--;
	}
  }
}
