/*
Viet chuong trinh nhap c�c so nguy�n n, a, b (a>0, a<b<1000, n<b-a) v� thuc hien:
a)	Tao danh s�ch lien ket L1 gom n so nguy�n ngau nhi�n trong khoang [a; b].
b)	Tao danh s�ch lien ket L2 gom n so nguy�n ngau nhi�n kh�c nhau trong khoang [a; b].
c)	Noi L2 v�o L1 de tao danh s�ch L.
d)	Kiem tra t�nh don dieu cua danh s�ch L.
e)	Kiem tra t�nh doi xung cua danh s�ch L.
f)	Nhap so nguy�n x, sau do t�m phan tu dau ti�n trong danh s�ch L c� gi� tri bang x. 
	Neu t�m thay, chen phan tu (x-1) v�o truoc phan tu x va (x+1) v�o sau phan tu x. 
	Neu kh�ng t�m thay, them (x-1) v�o dau danh s�ch va phan tu (x+1) v�o cuoi danh s�ch.
g)	Nhap mot so nguy�n x, 
	sau do x�c dinh xem c� bao nhi�u phan tu trong danh s�ch L c� gi� tri bang x. 
h)	Loai tat c� c�c phan tu c� gi� tri bang x ra khoi danh s�ch L.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100

typedef struct pt{
	   int data;
	   struct pt *next;
	} phantu;

/*
struct pt{
	   int data;
	   struct pt *next;
	};

typedef struct pt phantu;
*/


phantu *L1=NULL, *L2=NULL, *L=NULL;

int n, a, b, c, x;

void InDS(phantu *L);
void Nhapnab();
void caua(), caub(),cauc(),cauf(),caug(),cauh();
int caud(),caue();

main()
{
  Nhapnab();
  c=b-a;
  srand(time(NULL));
  caua(); printf("\n Danh sach L1:\n"); InDS(L1);
  caub(); printf("\n\n Danh sach khac nhau L2:\n"); InDS(L2);
  cauc(); printf("\n Danh sach L:\n"); InDS(L);
  printf("\n Danh sach %s don dieu...\n ", caud()?"":"khong");
  printf("\n Danh sach %s doi xung...\n ", caue()?"":"khong");
  cauf(); printf("\n Danh sach sau khi chen ...\n "); InDS(L);
  caug();
  cauh(); InDS(L);
}
 
void InDS(phantu *L)
{
  phantu *p;
  int i=0;

  p=L;
  while (p!=NULL){
    printf("\n%3d: %d ",++i,p->data);
    p=p->next;
  }
  printf("\n");
}


void Nhapnab()
{
 	printf("a= "); scanf("%d", &a);
 	printf("b>a : "); scanf("%d", &b);
 	printf("n<b-a : "); scanf("%d", &n);
 	printf("\n Danh sach gom cac so nhap trong (%d;%d)\n",a,b);
}

void caua()
{
  int i; 
  phantu *p;
  
  for (i=0; i<n; i++){
    p=(phantu *) malloc(sizeof(phantu));
    p->data=rand()%c+a;
    p->next=L1;
    L1=p;
    }
}

void caub()
{
  int i, j, k, N, t[MAX];
  phantu *p;
  
  N=c; for (i=0; i<N; i++) t[i]=i; 
  for (i=0; i<n; i++){ 
    k=rand()%N; 
    for (j=k; j<N; j++) t[j]=t[j+1]; 
    N--;
    p=(phantu *) malloc(sizeof(phantu));
    p->data=t[k]+a; 
    p->next=L2;
    L2=p;
  }
}

void cauc()
{
  phantu *p;
  L=L1;
  p=L;
  if (p==NULL) return;
  while (p->next!=NULL) p=p->next;
  p->next=L2;
  n=2*n;
}

int caud()
{
  int i, sign;
  phantu *p;
  
  if (L==NULL||L->next==NULL) return 0; // danh sach rong hoac co 1 phan tu
  sign=L->next->data-L->data;
  p=L->next;
  for (i=1; i<n-1; i++){//danh sach gom n phan tu
    if (sign*(p->next->data-p->data)<=0) return 0;
    p=p->next;
  }
  return 1;
}

int caue() // ds rong duoc xem la doi xung
{
  phantu *p;
  int i=0, j, x[MAX];
  
  p=L;
  while (p!=NULL){
    x[i++]=p->data;
    p=p->next;
  }
  i=0; j=n-1;
  while (i<j && x[i]==x[j]){
  	i++; j--;
  }
  return i>=j;
}

void cauf()
{
  int x;
  phantu *p,*q, *r;
  
  printf("Chen x-1 va x+1 voi x= "); scanf("%d", &x);
  p=L;  while (p!=NULL && p->data!=x) p=p->next; 
  
  if (p==NULL){
	q=(phantu *) malloc(sizeof(phantu));  q->data=x+1; 	q->next=NULL;
	if (L!=NULL){
		r=L; while (r->next!=NULL) r=r->next; 
		r->next=q;	
	}
	else L=q;  
	q=(phantu *) malloc(sizeof(phantu));
  	q->data=x-1;
	q->next=L;
	L=q;  	  	
  } 
  else{
  	q=(phantu *) malloc(sizeof(phantu)); q->data=x+1; q->next=p->next;
  	p->next=q;	
  	q=(phantu *) malloc(sizeof(phantu));
  	q->data=x-1;
	if (p==L){
		q->next=L;
		L=q;  	  	
	}
	else{
		p=L;  while (p->next->data!=x) p=p->next;
		q->next=p->next;
		p->next=q;
	} 
  }  
}

void caug()
{
  int x,c;
  phantu *p;
  
  printf("So can dem x= "); scanf("%d", &x);
  c=0;
  p=L;
  while (p!=NULL){
    if (p->data==x) c++;
    p=p->next;
  }
  printf("Co %d so %d...\n",c,x);
}

void cauh()
{
  phantu *p;
  
  printf("Phan tu can loai x= "); scanf("%d", &x);
  // loai cac phan tu dau == x 
  p=L; while (p!=NULL && p->data==x) p=p->next; 
  L=p;
  if (p==NULL) return; //tat ca deu bang x hoac danh sach rong
  while (p->next!=NULL){
    if (p->next->data==x) p->next=p->next->next;
    else p=p->next;
  }
}
