#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100

typedef struct pt{
	   int data;
	   struct pt *next;
	} phantu;

typedef phantu* PTR;
int n, a, b, c;
PTR L=NULL, R=NULL;
void InDS(PTR L), Nhapnab(), TaoDS();

main()
{ 	
  Nhapnab();
  TaoDS(); 
  printf("\n Danh sach L:\n"); InDS(L);
  return 0;
}
 
void InDS(PTR L)
{
  int i;

  for (i=0; i<2*n+1; i++){
   	printf("\n%3d: %d ", i+1, L->data);
   	L=L->next;
  }
}

void Nhapnab()
{
 	printf("a= "); scanf("%d", &a);
 	printf("b>a : "); scanf("%d", &b);
 	c=b-a;
 	printf("n<%d : ", c); scanf("%d", &n);
 	printf("\n Danh sach gom %d so phat sinh trong (%d;%d)\n",n,a,b);
}
// chen p moi vao giua R va L
void TaoDS()
{
  int i, x; 
  PTR p;
  
  srand(time(NULL));
  for (i=0; i<n; i++){
    	p=(phantu *) malloc(sizeof(phantu));
    	p->data=x=rand()%c+a; printf("\n%3d: %d", i+1, x);
		if (L==NULL) L=p;
		p->next=L;
    	if (R!=NULL) R->next=p;
		R=p;	 			 
  }
}
