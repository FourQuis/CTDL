#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100

typedef struct pt{
	   int data;
	   struct pt *next;
	} phantu;

typedef phantu* PTR;
int n, a, b, c;
PTR L=NULL;
void InDS(PTR L), Nhapnab(), TaoDS(), DaoDS(PTR &L);

main()
{ 	
  Nhapnab();
  TaoDS(); 
  printf("\n Danh sach L:\n"); InDS(L);
  DaoDS(L); printf("\n Danh sach sau khi dao:\n"); InDS(L);
}
 
void InDS(PTR L)
{
  PTR p;
  int i=0;

  p=L;
  while (p!=NULL){
    printf("\n%3d: %d ",++i,p->data);
    p=p->next;
  }
  printf("\n");
}

void Nhapnab()
{
 	printf("a= "); scanf("%d", &a);
 	printf("b>a : "); scanf("%d", &b); c=b-a;
 	printf("n<%d : ", c); scanf("%d", &n);
 	printf("\n Danh sach gom %d so phat sinh trong (%d;%d)\n",n,a,b);
}

void TaoDS()
{
  int i; 
  PTR p;
  
  srand(time(NULL));
  for (i=0; i<n; i++){
    	p=(phantu *) malloc(sizeof(phantu));
    	p->data=rand()%c+a;
    	p->next=L;
    	L=p; 
  }
}

void DaoDS(PTR &L)
{
  	PTR p, q;
  
  	p=NULL;
  	while (L!=NULL){
  		q=L->next;
		L->next=p;
		p=L;
		L=q;
  	} 
  	L=p;
}
