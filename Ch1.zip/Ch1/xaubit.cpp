#include <stdio.h>

#define MAX 20
int S[MAX], c=0, n; 

void Try(int), print();

main()
{
  printf("nhap n="); scanf("%d", &n);
  Try(1);
}

void Try(int i)
{
  int j;
  for (j=0; j<=1; j++){
    S[i]=j;
    if (i==n) print(); else Try(i+1);
  }
}

void print()
{
  int i;
  printf("\n%3d:",++c);
  for (i=1; i<=n; i++) printf("%d", S[i]);
}
