//Doi n sang so La ma voi n<4000
#include <stdio.h>
#include <time.h>
#include <stdlib.h> 
#include <string.h> 

main () 
{
	int n,d,i=0,k,len=0;
	char digit[8]="IVXLCDM";
	char s[20]="";
	
    srand(time (NULL));
    //n= rand()%5000;
    printf("n = "); scanf("%d", &n);	
    while (n){
    	d=n%10; 
    	n/=10;
    	if (d<4) for (k=0; k<d; k++) { s[len]=digit[2*i];len++;}
    	else  if (d==4) { s[len]=digit[2*i+1];s[len+1]=digit[2*i];len+=2;}
    	      else 	if (d==9) { s[len]=digit[2*i+2];s[len+1]=digit[2*i];len+=2;}
    				else {
    					d-=5;
    					for (k=0; k<d; k++) { s[len]=digit[2*i];len++;}
    					s[len]=digit[2*i+1];len++;
					}			
    	i++;
	}
    strrev(s);
    printf("%s",s);
	
	//Doi nguoc lai
	
	for (i=0; i<len; i++){
		switch (s[i]){
			case 'M': n+=1000; break; 
			case 'D': n+=500; break;
			case 'C': if (s[i+1]=='M'||s[i+1]=='D')n-=100; else n+=100; break;
			case 'L': n+=50; break;
			case 'X': if (s[i+1]=='C'||s[i+1]=='L')n-=10; else n+=10; break;
			case 'V': n+=5; break;
			case 'I': if (s[i+1]=='X'||s[i+1]=='V')n-=1; else n+=1; break;
		}
		//printf("\ns[%d]=%c, n=%d",i,s[i],n);
	}
	printf("\nDoi nguoc lai n=%d",n);	
}
