#include<stdio.h>

unsigned GCD(unsigned a, unsigned b)
{
	if (a == 0)	return b;
	else return GCD(b % a, a);
}

main()
{
    unsigned a,b;

	printf("a = "); scanf("%u",&a);
	printf("b = "); scanf("%u",&b);
    printf("(%d;%d) = %d",a,b,GCD(a,b));
}
