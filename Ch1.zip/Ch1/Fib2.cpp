#include <stdio.h>
#define MAX 10000

int main()
{
    int n,x=1,y=1,z=1;
    for (n=2; n<MAX; n++){
    	z=x+y;
    	x=y;
    	y=z;
    	printf("F(%d)= %d\n",n,z);
	} 
}
