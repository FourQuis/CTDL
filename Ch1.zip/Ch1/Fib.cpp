#include <stdio.h>
#define MAX 45

int Fib(int n);

int main()
{
	
    int n;
    
    for (n=0; n<MAX; n++);
 	 	printf("F(%d)= %d\n",n,Fib(n));
}

int Fib(int n)
{
    if (n<2) return 1;
	return Fib(n-1)+Fib(n-2);
}
