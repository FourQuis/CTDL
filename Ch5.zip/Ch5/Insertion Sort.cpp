/*
  Insertion Sort
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h> 

#define VMAX 10
#define MAX 10

int A[MAX], n;
void Generate(), PrintA(), InsertionSort();

main () 
{
	int i;
	
	Generate();
	printf("\n");
	InsertionSort();
}

void Generate()
{
  int i, j, k, N, t[VMAX];
  
  srand(time(NULL));
  n=3+rand()%(MAX-3); n=7;
  N=VMAX; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    A[i]=t[k]; 
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
  }
  PrintA();
}

void InsertionSort()
{
  int i, j, x;
  
  for (i=1; i<n; i++){
	x=A[i]; printf("x=%3d: ",x);
	j=i-1;  
  	while (j>=0 && A[j]>x){
  	  A[j+1]=A[j];
  	  j--;
	}
	A[j+1]=x;
	PrintA();
  }	   
}

void PrintA()
{
	int i;
	
	for (i=0; i<n; i++) printf("%3d",A[i]); printf("\n");
	//system("pause");
}
