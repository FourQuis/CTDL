/*
  Tim kiem nhi phan lap
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h> 

#define VMAX 10
#define MAX 10

int A[MAX], n;
void Generate(), PrintA(), QuickSort(int, int);
int  BSearch(int x);

main () 
{
	int i, x;
	
	Generate();  PrintA();
	QuickSort(0,n-1);	PrintA();
	printf("So can tim x= "); scanf("%d", &x);
	i=BSearch(x);
	if (i<0) printf("Khong co so %d ...",x); else printf("A[%d]=%d",i,x);
}

void Generate()
{
  int i, j, k, N, t[VMAX];
  
  srand(time(NULL));
  n=3+rand()%(MAX-80); n=7;
  N=VMAX; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    A[i]=t[k]; 
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
  }
}

void QuickSort(int left, int right)
{
  int i, j, x, temp;
  
  i=left; j=right; x = A[(left+right)/2];
  do{
	while (A[i]<x) i++;
    while (A[j]>x) j--;
  	if (i<=j){
  		temp=A[i]; A[i]=A[j]; A[j]=temp;
  		i++; j--;
	  }
  } while (i<=j);
  if (j>left) QuickSort(left, j);
  if (i<right) QuickSort(i, right);
}

int BSearch(int x)
{
  int mid,i,j;
  
  i=0; j=n-1;
  while (i<=j){
       mid = (i+j)/2; printf("%d-->%d\n",A[i],A[j]);
       if (x == A[mid]) return mid;
       else if (x < A[mid]) j=mid-1;
       else i=mid+1;
     }
  return -1;   
}

void PrintA()
{
	int i;
	
	for (i=0; i<n; i++) printf("%3d",A[i]); printf("\n");
	//system("pause");
}
