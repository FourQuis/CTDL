#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define MAX 1000

struct node{
	int key;
	struct node *left;
	struct node *right;
};
typedef struct node *NODEPTR;
NODEPTR  R; int a, b, n;

void Inputnab()
{
 printf("a= "); scanf("%d", &a);
 printf("b>%d : ",a); scanf("%d", &b);
 printf("n<%d : ",b-a); scanf("%d", &n);
}
//cap phat bo nho
NODEPTR Getnode(){
	NODEPTR r;
	r=(NODEPTR) malloc(sizeof(struct node));
	return(r);
}
//tao moi cho nut de dua vao cay
NODEPTR Makenode(int x){
	NODEPTR r;
	r=Getnode();
	r->key=x;
	r->left=NULL;
	r->right=NULL;
	return(r);
}
void Insert(int x, NODEPTR *r)
{
     NODEPTR p;
     p=Makenode(x);
     if (*r==NULL) *r=p;
     else if(x<(*r)->key) Insert(x,&((*r)->left));
	  else Insert(x,&((*r)->right));
}

void MakeTree()
{
  int x, i, j, k, N, t[MAX];
  R=NULL;
  srand(time(NULL));
  N=b-a; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    x=t[k]+a; 
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
    printf("\n%d ",x);
    Insert(x,&R);
  }
  printf("\nnhap xong\n "); getchar();
}
//tien tu
void NLR(NODEPTR proot){
	if(proot!=NULL){
		printf("%d ",proot->key);
		NLR(proot->left);
		NLR(proot->right);
	}
}
// trung tu
void LNR(NODEPTR proot){
	if(proot!=NULL){
		LNR(proot->left);
		printf("%d ",proot->key);
		LNR(proot->right);
	}
}
//hau tu
void LRN(NODEPTR proot){
	if(proot!=NULL){
		LRN(proot->left);
		LRN(proot->right);
		printf("%d ",proot->key);
	}
}
// In theo thu tu giam
void RNL(NODEPTR proot){
	if(proot!=NULL){
		RNL(proot->right);
		printf("%d ",proot->key);
		RNL(proot->left);
	}
}
//Dem tong so nut
int Node(NODEPTR proot){
	if(proot!=NULL) return 1+Node(proot->right)+Node(proot->left);
	else return 0;
}

// Dem so nut la
int Leaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) return 1;
		else return Leaf(proot->right)+Leaf(proot->left);
	else return 0;	
}

// Tinh chieu cao 
int Height(NODEPTR proot)
{
  	int a, b;
  	
	if(proot==NULL) return 0;
  	a=Height(proot->left);
	b=Height(proot->right);
	if(a>b) return a+1;
	else return b+1;
}

// In c�c nut la
void PrintLeaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) printf("%d ",proot->key);
		else{
		 	PrintLeaf(proot->left);
			PrintLeaf(proot->right); 
		} 	
}

// In c�c nut nhanh
void PrintBranch(NODEPTR proot){
	if(proot!=NULL){
	  if (proot->left!=NULL || proot->right!=NULL) printf("%d  ",proot->key);
	  PrintBranch(proot->left);
	  PrintBranch(proot->right);  	
	}
}
//Tim x tra ve p va nut cha parent de dung ve sau
void Search(int x, NODEPTR root, NODEPTR *p, NODEPTR *parent, int *found)
{     
     *p=root;
	 *parent=NULL;
	 *found=0;
	 while (!*found && *p!=NULL){
	 	if (x==(*p)->key) *found=1;
	 	else{
	 		*parent=*p;
	 		if (x<(*p)->key) *p=(*p)->left;
	 		else if (x>(*p)->key) *p=(*p)->right;
		 }
	 }
}

void Delete(int x,NODEPTR *root)
{
	NODEPTR p, parent, pSucc, SubTree;
	int found;
	
	Search(x,*root,&p,&parent,&found);
	if (!found){
		printf("\n khong co phan tu %d ... ",x);
		return;
	}
	if (p->left!=NULL && p->right!=NULL){
		//Tim phan tu pSucc ben trai nhat cua cay con ben phai (nho nhat >=x) 
		pSucc=p->right;
		parent=p;
		while(pSucc->left!=NULL){//xuong ben trai
			parent=pSucc;
			pSucc=pSucc->left;
		}
		//Chuyen khoa key cua pSucc vao p, dua p den pSucc va se xoa p (chi co cay con ben phai)
		p->key=pSucc->key;
		p=pSucc;
	}
	//xoa nut p co nhieu nhat 1 cay con
	SubTree=p->left;
	if (SubTree==NULL) SubTree=p->right;
	if (parent==NULL) // xoa nut goc
	  	*root=SubTree;
	else if (parent->left==p) parent->left=SubTree;
		 else parent->right=SubTree;
}

main()
{ 
   int x, found;
   NODEPTR p, parent;
   
   Inputnab();
   MakeTree();
   printf("\nNLR(Tien tu):  ");    NLR(R);
   printf("\n\nLNR(Tang dan):  ");   LNR(R);
   printf("\n\nRNL(giam dan):  ");   RNL(R);
   printf("\nso nut = %d", Node(R));
   printf("\nso nut la= %d", Leaf(R));
   printf("\nCac nut la: "); PrintLeaf(R);
   printf("\nCac nut nhanh: "); PrintBranch(R);
   printf("\nSo can tim x= "); scanf("%d",&x);
   Search(x,R,&p,&parent,&found);
   if (found)
   		if (parent==NULL) printf("\nNut goc co gia tri %d ",x);
   		else {
   	  		printf("\nparent->key= %d\np->key=%d\n ",parent->key,p->key);
   		} 
   else printf("\nkhong co so %d ... ",x);
   printf("\nSo can xoa hoac chen x= "); scanf("%d",&x);
   Search(x,R,&p,&parent,&found);
   if (found) Delete(x,&R);
   		else Insert(x,&R);
   printf("\nLNR(Trung tu):  ");    LNR(R);
   getchar();
}
