#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
// them truong level de luu muc cua moi nut. Chieu cao cua cay la muc cao nhat cua cac nut.
struct node{
	char keyword[20];
	struct node *left;
	struct node *right;
};
typedef struct node *NODEPTR;
char words[][20]=
{"typedef", "char", "int", "short", "long", "signed", "unsigned","float", "double", 
 "void", "enum", "sizeof", "auto", "static", "struct", "union", "if", "else", "switch",
 "case", "break", "continue", "default", "for", "do", "while", "return"};

NODEPTR  R; int a, b, n=27;
//cap phat bo nho
NODEPTR Getnode(){
	NODEPTR r;
	r=(NODEPTR) malloc(sizeof(struct node));
	return(r);
}
//tao moi cho nut de dua vao cay
NODEPTR Makenode(char x[]){
	NODEPTR r;
	r=Getnode();
	strcpy(r->keyword,x);
	r->left=NULL;
	r->right=NULL;
	return(r);
}
void Insert(char x[], NODEPTR *r)
{
     NODEPTR p;
     p=Makenode(x);
     if (*r==NULL) *r=p;
     else if(strcmp(x,(*r)->keyword)<0)
	     if((*r)->left==NULL) (*r)->left=p;
	     else Insert(x,&((*r)->left));
	  else if((*r)->right==NULL) (*r)->right=p;
	       else Insert(x,&((*r)->right));
}
void MakeTree()
{
  int x, i;
  R=NULL;
  for (i=0; i<n; i++) Insert(words[i], &R);
}
//tien tu
void NLR(NODEPTR proot){
	if(proot!=NULL){
		printf("%s ",proot->keyword);
		NLR(proot->left);
		NLR(proot->right);
	}
}
// trung tu
void LNR(NODEPTR proot){
	if(proot!=NULL){
		LNR(proot->left);
		printf("%s ",proot->keyword);
		LNR(proot->right);
	}
}
//hau tu
void LRN(NODEPTR proot){
	if(proot!=NULL){
		LRN(proot->left);
		LRN(proot->right);
		printf("%s ",proot->keyword);
	}
}
// In theo thu tu giam
void RNL(NODEPTR proot){
	if(proot!=NULL){
		RNL(proot->right);
		printf("%s ",proot->keyword);
		RNL(proot->left);
	}
}
//Dem tong so nut
int Node(NODEPTR proot){
	if(proot!=NULL) return 1+Node(proot->right)+Node(proot->left);
}

// Dem so nut la
int Leaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) return 1;
		else return Leaf(proot->right)+Leaf(proot->left);
	
}
//Tinh chieu cao
int Height(NODEPTR proot)
{
  	int a, b;
  	
	if(proot==NULL) return 0;
  	a=Height(proot->left);
	b=Height(proot->right);
	if(a>b) return a+1;
	else return b+1;
}

// In c�c nut la
void PrintLeaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) printf("%s ",proot->keyword);
		else{
		 	PrintLeaf(proot->left);
			PrintLeaf(proot->right); 
		} 	
}

// In c�c nut nhanh
void PrintBranch(NODEPTR proot){
	if(proot!=NULL){
	  if (proot->left!=NULL || proot->right!=NULL) printf("%s ",proot->keyword);
	  PrintBranch(proot->left);
	  PrintBranch(proot->right);  	
	}
}
//Tim x tra ve p va nut cha parent de dung ve sau
void Search(char x[], NODEPTR root, NODEPTR *p, NODEPTR *parent, int *found)
{     
     *p=root;
	 *parent=NULL;
	 *found=0;
	 while (!*found && *p!=NULL){
	 	if (strcmp(x,(*p)->keyword)==0) *found=1;
	 	else{
	 		*parent=*p;
	 		if (strcmp(x,(*p)->keyword)<0) *p=(*p)->left;
	 		else if (strcmp(x,(*p)->keyword)>0) *p=(*p)->right;
		 }
	 }
}

void Delete(char x[],NODEPTR *root)
{
	NODEPTR p, parent, pSucc, SubTree;
	int found;
	
	Search(x,*root,&p,&parent,&found);
	if (!found){
		printf("\n khong co tu khoa %s ... ",x);
		return;
	}
	if (p->left!=NULL && p->right!=NULL){
		//Tim phan tu ben trai nhat cua cay con ben phai
		pSucc=p->right;
		parent=p;
		while(pSucc->left!=NULL){//xuong ben trai
			parent=pSucc;
			pSucc=pSucc->left;
		}
		//Chuyen khoa key cua pSucc vao p va chi p den pSucc se xoa p
		strcpy(p->keyword,pSucc->keyword);
		p=pSucc;
	}
	SubTree=p->left;
	if (SubTree==NULL) SubTree=p->right;
	if (parent==NULL) // xoa nut goc
	  	*root=SubTree;
	else if (parent->left==p) parent->left=SubTree;
		 else parent->right=SubTree;
}

main()
{
   int found;
   char x[10];
   NODEPTR p, parent;

   for (int i=0; i<n; i++) puts(words[i]);
   MakeTree();
   printf("\nLNR)(Tang dan):  ");   LNR(R);
   printf("\nRNL(Giam dan):  ");   RNL(R);
   printf("\nSo nut = %d", Node(R));
   printf("\nSo nut la = %d", Leaf(R));
   printf("\nChieu cao h = %d",Height(R));
   printf("\nCac nut la: "); PrintLeaf(R);
   printf("\nCac nut nhanh: "); PrintBranch(R);
   printf("\nTu khoa can tim x= "); gets(x);
   Search(x,R,&p,&parent,&found);
   if (found)
   		if (parent==NULL) printf("\nTu khoa goc la: %s ",x);
   		else {
   	  		printf("\nparent->keyword= %s\np->keyword=%s\n ",parent->keyword,p->keyword);
   		} 
   else printf("\nkhong co tu khoa %s ... ",x);
   printf("\nTu khoa can xoa hoac chen x= "); gets(x);
   Search(x,R,&p,&parent,&found);
   if (found) Delete(x,&R);
   		else Insert(x,&R);
   LNR(R);
   getchar();
   getchar();
}
