#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define MAX 1000

struct node{
	int key;
	struct node *left;
	struct node *right;
};
typedef struct node *NODEPTR;
NODEPTR  R; int a, b, n;

void Inputnab()
{
 printf("a= "); scanf("%d", &a);
 printf("b>%d : ",a); scanf("%d", &b);
 printf("n<%d : ",b-a); scanf("%d", &n);
}
//cap phat bo nho
NODEPTR Getnode(){
	NODEPTR r;
	r=(NODEPTR) malloc(sizeof(struct node));
	return(r);
}
//tao moi cho nut de dua vao cay
NODEPTR Makenode(int x){
	NODEPTR r;
	r=Getnode();
	r->key=x;
	r->left=NULL;
	r->right=NULL;
	return(r);
}
void Insert(int x, NODEPTR *r)
{
     NODEPTR p;
     p=Makenode(x);
     if (*r==NULL) *r=p;
     else if(x<(*r)->key) Insert(x,&((*r)->left));
	      else Insert(x,&((*r)->right));
}

void MakeTree()
{
  int x, i, j, k, N, t[MAX];
  R=NULL;
  srand(time(NULL));
  N=b-a; 
  for (i=0; i<N; i++) t[i]=i;
  for (i=0; i<n; i++){
    k=rand()%N;
    x=t[k]+a; 
    for (j=k; j<N; j++) t[j]=t[j+1];
    N--;
    printf("\n%d ",x);
    Insert(x,&R);
  }
  printf("\nnhap xong\n "); getchar();
}
//tien tu
void NLR(NODEPTR proot){
	if(proot!=NULL){
		printf("%d ",proot->key);
		NLR(proot->left);
		NLR(proot->right);
	}
}
// trung tu
void LNR(NODEPTR proot){
	if(proot!=NULL){
		LNR(proot->left);
		printf("%d ",proot->key);
		LNR(proot->right);
	}
}
//hau tu
void LRN(NODEPTR proot){
	if(proot!=NULL){
		LRN(proot->left);
		LRN(proot->right);
		printf("%d ",proot->key);
	}
}
// In theo thu tu giam
void RNL(NODEPTR proot){
	if(proot!=NULL){
		RNL(proot->right);
		printf("%d ",proot->key);
		RNL(proot->left);
	}
}
//Dem tong so nut
int Node(NODEPTR proot){
	if(proot!=NULL) return 1+Node(proot->right)+Node(proot->left);
	else return 0;
}

// Dem so nut la
int Leaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) return 1;
		else return Leaf(proot->right)+Leaf(proot->left);
	else return 0;	
}

// Tinh chieu cao 
int Height(NODEPTR proot)
{
  	int a, b;
  	
	if(proot==NULL) return 0;
  	a=Height(proot->left);
	b=Height(proot->right);
	if(a>b) return a+1;
	else return b+1;
}

main()
{ 
   Inputnab();
   MakeTree();
   printf("\nNLR(Tien tu):  ");    NLR(R);
   printf("\n\nLNR(Tang dan):  ");   LNR(R);
   printf("\n\nRNL(giam dan):  ");   RNL(R);
   printf("\nso nut = %d", Node(R));
   printf("\nso nut la= %d", Leaf(R));
   printf("\nChieu cao = %d", Height(R));
   getchar();
}

