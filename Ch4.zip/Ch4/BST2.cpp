#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
// them truong level de luu muc cua moi nut. Chieu cao cua cay la muc cao nhat cua cac nut.
struct node{
	char keyword[20];
	struct node *left;
	struct node *right;
};
typedef struct node *NODEPTR;
char words[][20]=
{"typedef", "char", "int", "short", "long", "signed", "unsigned","float", "double", 
 "void", "enum", "sizeof", "auto", "static", "struct", "union", "if", "else", "switch",
 "case", "break", "continue", "default", "for", "do", "while", "return"};

NODEPTR  R; int a, b, n=27;
//cap phat bo nho
NODEPTR Getnode(){
	NODEPTR r;
	r=(NODEPTR) malloc(sizeof(struct node));
	return(r);
}
//tao moi cho nut de dua vao cay
NODEPTR Makenode(char x[]){
	NODEPTR r;
	r=Getnode();
	strcpy(r->keyword,x);
	r->left=NULL;
	r->right=NULL;
	return(r);
}
void Insert(char x[], NODEPTR *r)
{
     NODEPTR p;
     p=Makenode(x);
     if (*r==NULL) *r=p;
     else if(strcmp(x,(*r)->keyword)<0)
	     if((*r)->left==NULL) (*r)->left=p;
	     else Insert(x,&((*r)->left));
	  else if((*r)->right==NULL) (*r)->right=p;
	       else Insert(x,&((*r)->right));
}
void MakeTree()
{
  int x, i;
  R=NULL;
  for (i=0; i<n; i++) Insert(words[i], &R);
}
//tien tu
void NLR(NODEPTR proot){
	if(proot!=NULL){
		printf("%s ",proot->keyword);
		NLR(proot->left);
		NLR(proot->right);
	}
}
// trung tu
void LNR(NODEPTR proot){
	if(proot!=NULL){
		LNR(proot->left);
		printf("%s ",proot->keyword);
		LNR(proot->right);
	}
}
//hau tu
void LRN(NODEPTR proot){
	if(proot!=NULL){
		LRN(proot->left);
		LRN(proot->right);
		printf("%s ",proot->keyword);
	}
}
// In theo thu tu giam
void RNL(NODEPTR proot){
	if(proot!=NULL){
		RNL(proot->right);
		printf("%s ",proot->keyword);
		RNL(proot->left);
	}
}
//Dem tong so nut
int Node(NODEPTR proot){
	if(proot!=NULL) return 1+Node(proot->right)+Node(proot->left);
	return 0;
}

// Dem so nut la
int Leaf(NODEPTR proot){
	if(proot!=NULL)
	  if (proot->left==NULL && proot->right==NULL) return 1;
		else return Leaf(proot->right)+Leaf(proot->left);
	
}
//Tinh chieu cao
int Height(NODEPTR proot)
{
  	int a, b;
  	
	if(proot==NULL) return 0;
  	a=Height(proot->left);
	b=Height(proot->right);
	if(a>b) return a+1;
	else return b+1;
}

main()
{
   for (int i=0; i<n; i++) puts(words[i]);
   MakeTree();
   printf("\nLNR)(Tang dan):  ");   LNR(R);
   printf("\nRNL(Giam dan):  ");   RNL(R);
   printf("\nSo nut = %d", Node(R));
   printf("\nSo nut la = %d", Leaf(R));
   printf("\nChieu cao h = %d",Height(R));
   getchar();
}
